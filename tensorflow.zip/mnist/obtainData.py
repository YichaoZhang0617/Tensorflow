#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao


# from tensorflow.contrib.learn.python.learn.datasets.mnist import read_data_sets
# mnist = read_data_sets("MNIST_data/", one_hot=True)

import numpy as np

import tensorflow as tf

# 返回将生成多少日志记录输出
old_v = tf.logging.get_verbosity()
# 为将要被记录的的东西（日志）设置开始入口
tf.logging.set_verbosity(tf.logging.ERROR)

from tensorflow.examples.tutorials.mnist import input_data

# 代码中的one_hot=True，表示将样本标签转化为one_hot编码。
# 举例来解释one_hot编码：假如一共有10类：0的one_hot为1000000000,1的ont_hot为0100000000，2的one_hot为0010000000，依次类推。只要有一个位为1,1所在的位置就代表着第几类

# 自动下载数据集并将文件解压到当前代码所在同级目录下的MNIST_data文件夹下，这里的read_data_sets是针对mnist数据集处理的，在mnist.py文件中定义的函数
mnist = input_data.read_data_sets("MNIST_data/", one_hot=True)

print(mnist)
print ('输入训练数据:',mnist.train.images)
# 数据集的标准形状(shape)为二维数组(samples, features)，其中samples表示数据集大小，features表示其中特征向量的维数。
print ('输入训练数据打印shape:',mnist.train.images.shape)

import pylab
# 显示第二张图，下标从0到54999
im = mnist.train.images[1]
# 先前我们不知道im的shape属性是多少，但是想让im变成28列，行数不知道多少
im = im.reshape(-1,28)
pylab.imshow(im)
pylab.show()
print ('输入测试数据打印shape:',mnist.test.images.shape)
print ('输入验证数据打印shape:',mnist.validation.images.shape)


train_data = mnist.train.images  # Returns np.array
# asarray 表示将输入数据（列表的列表，元组的元组，元组的列表等）转换为矩阵形式
train_labels = np.asarray(mnist.train.labels, dtype=np.int32)
eval_data = mnist.test.images  # Returns np.array
# asarray 表示将输入数据（列表的列表，元组的元组，元组的列表等）转换为矩阵形式
eval_labels = np.asarray(mnist.test.labels, dtype=np.int32)

tf.logging.set_verbosity(old_v)

# 这里的None表示此张量的第一个维度可以是任何长度的，placeholder用于添加占位符
x = tf.placeholder("float", [None, 784])

# 这里的Variable代表一个可修改的张量，w表示权重，b表示偏置量
W = tf.Variable(tf.zeros([784,10]))
b = tf.Variable(tf.zeros([10]))

y = tf.nn.softmax(tf.matmul(x,W) + b)

# placeholder用于添加占位符
y_ = tf.placeholder("float", [None,10])

# y_表示实际的分布，y表示预测的分布

# 计算交叉熵（损失函数），目的是尽量使损失函数最小
cross_entropy = -tf.reduce_sum(y_*tf.log(y))

# TensorFlow用梯度下降算法（gradient descent algorithm）以0.01的学习速率最小化交叉熵
train_step = tf.train.GradientDescentOptimizer(0.01).minimize(cross_entropy)

# 添加一个操作来初始化我们创建的模型参数
init = tf.global_variables_initializer()

sess = tf.Session()
sess.run(init)

# 开始模型训练，让模型循环训练1000次
for i in range(1000):
  #（batch_xs, batch_ys）分别表示100组数据的权重和偏置量
  batch_xs, batch_ys = mnist.train.next_batch(100)
  # 用这些数据点作为参数替换之前定义的占位符来运行train_step。
  sess.run(train_step, feed_dict={x: batch_xs, y_: batch_ys})

# 用 tf.equal 来检测我们的预测是否真实标签匹配(索引位置一样表示匹配)
correct_prediction = tf.equal(tf.argmax(y,1), tf.argmax(y_,1))

# 将布尔值转换为浮点数，并取平均值
accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))

print(sess.run(accuracy, feed_dict={x: mnist.test.images, y_: mnist.test.labels}))



