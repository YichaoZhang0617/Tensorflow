#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

import tensorflow as tf
import numpy as np


p = np.array([[1,2],[3,4]])
print(p)

x = np.random.random((3, 2)) - 0.5

x2 = [[1,2,3],[-2,6,-8],[1,2,-5]]
y = np.maximum(x2, 0)

x = np.array([[[5,10,15,30,25],[20,30,65,70,90],[7,80,95,20,30]],[[3,0,5,0,45],[12,-2,6,7,90],[18,-9,95,120,30]],[[17,13,25,30,15],[23,36,9,7,80],[1,-7,-5,22,3]]])

print(x)

matrix1 = tf.constant([[3.,3.]])
matrix2 = tf.constant([[2.],[2.]])

product = tf.matmul(matrix1, matrix2)

# 启动默认图
sess = tf.Session()
result = sess.run(product)

sess.close()
print(result)



# Initialize two constants
x1 = tf.constant([1,2,3,4])
x2 = tf.constant([5,6,7,8])

# Multiply
result1 = tf.multiply(x1, x2)

sess = tf.Session()
# Print the result
print(sess.run(result1))

